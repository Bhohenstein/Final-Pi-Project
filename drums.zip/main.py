def percussion(): # Play drums and cymbals
   self.key11.invoke()
   self.key10.invoke()
   self.key11.invoke()
   self.key10.invoke()
   
   self.button7 = Button(self.parent, text = "Percussion", fg="green",command = stars)  
   self.button7.grid(row=0,column=3,stikcy=N+S+E+W)     
perc = [pygame.mixer.Sound("Basic_Rock_135.mp3")] 